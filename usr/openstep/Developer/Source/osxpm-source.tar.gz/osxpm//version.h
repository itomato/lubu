#define VERSION "Lubu OpenMagic 1.0, 06/03/10"
